import { React, useState, useEffect } from "react";
import { H1 } from "../components/ui/H1";
import { Modal } from "../components/ui/Modal";
import { getIcon } from "../lib/utils";
import { mocks } from "../data/mock";
import { Trash2, Pencil } from "lucide-react";

export const Expenses = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [rating, setRating] = useState(0);

  const handleSliderChange = (event) => {
    setRating(event.target.value, 10);
  };

  return (
    <main className="">
      <div className="flex flex-col justify-center p-6 text-center">
        <H1>Expenses</H1>
        <input
          className="w-10/12 p-2 m-2 mx-auto mt-8 text-gray-700 bg-gray-200 sm:w-72 rounded-xl"
          type="text"
          placeholder="Search Expenses..."
        />
      </div>
      <div className="flex max-sm:justify-center">
        <button
          className="w-8/12 p-2 mt-8 text-white border sm:w-72 lg:ml-5 bg-black/40 rounded-xl"
          onClick={() => setIsOpen(true)}
        >
          Add Expense
        </button>
      </div>
      <div className="grid gap-5 p-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 place-items-center">
        <div>
          {mocks?.map((expense) => (
            <div
              className="w-full max-w-sm p-6 m-3 text-center text-white border shadow-lg hover:-translate-y-1 hover:scale-100 shadow-red-500/10 bg-gray-500/10 border-gray rounded-2xl hover:shadow-black/40 xl:w-full lg:w-11/12 sm:m-0 sm:mb-4"
              key={expense.id}
            >
              <div className="flex justify-end gap-3">
                <Trash2 className="w-5 h-5 text-red-500 cursor-pointer" />
                <Pencil className="w-5 h-5 cursor-pointer text-sky-400" />
              </div>
              <span className="text-2xl font-semibold break-words sm:text-xl ">
                {expense.title}
              </span>

              <div className="flex items-center w-2/3 mt-4 sm:w-full">
                <span className="px-2 text-xl sm:text-lg sm:px-8 sm:mx-auto">
                  ₪{expense.amount.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between mt-12">
                <span className="px-2 mr-auto text-xl text-zinc-500 sm:text-lg">
                  {expense.date}
                </span>
                <p className="text-zinc-500">{expense.rating}</p>
              </div>
            </div>
          ))}
        </div>

        {isOpen ? (
          <Modal setIsOpen={setIsOpen} isOpen={isOpen} title="New Expense">
            <form className="flex flex-wrap justify-center p-6 m-4 gap-y-7">
              <div className="w-full">
                <label htmlFor="title" className="font-semibold">
                  Title
                </label>
                <input
                  name="title"
                  type="text"
                  className="w-full h-8 pl-2 rounded-lg"
                  placeholder="Title"
                />
              </div>
              <div className="w-full">
                <label htmlFor="amount" className="font-semibold">
                  Amount
                </label>
                <input
                  name="amount"
                  type="number"
                  className="w-full h-8 pl-2 rounded-lg"
                  placeholder="Amount"
                />
              </div>
              <div className="w-full">
                <label htmlFor="date" className="font-semibold">
                  Date
                </label>
                <input
                  name="date"
                  type="date"
                  className="w-full h-8 pl-2 rounded-lg"
                  placeholder="Date"
                />
              </div>
              <div className="w-full">
                <div className="relative mb-6">
                  <input
                    type="range"
                    className="w-full accent-zinc-800"
                    min="0"
                    max="100"
                    step="1"
                    value={rating}
                    onChange={handleSliderChange}
                  />
                  <span className="absolute left-0 text-sm text-gray-500 dark:text-gray-400 -bottom-6">
                    😅
                  </span>
                  <span className="absolute text-sm text-gray-500 transform -translate-x-1/2 dark:text-gray-400 left-1/4 rtl:translate-x-1/2 -bottom-6">
                    😊
                  </span>
                  <span className="absolute text-sm text-gray-500 transform -translate-x-1/2 dark:text-gray-400 left-1/2 rtl:translate-x-1/2 -bottom-6">
                    😁
                  </span>
                  <span className="absolute text-sm text-gray-500 transform -translate-x-1/2 dark:text-gray-400 left-3/4 rtl:translate-x-1/2 -bottom-6">
                    😀
                  </span>
                  <span className="absolute right-0 text-sm text-gray-500 dark:text-gray-400 -bottom-6">
                    🤑
                  </span>
                </div>
                <div className="mt-8 text-center">
                  Current Rating: <b>{rating}</b> - Current Icon:
                  {getIcon(rating)}
                </div>
              </div>
              <button className="w-8/12 p-2 mt-8 text-white bg-black border sm:w-72 lg:ml-5 rounded-xl">
                Add
              </button>
            </form>
          </Modal>
        ) : null}
      </div>
    </main>
  );
};

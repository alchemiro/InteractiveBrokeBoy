export const mocks = [
  {
    id: 1,
    title: "Mock 1",
    amount: 1000,
    date: "2001-9-11",
    rating: "😀",
  },
];

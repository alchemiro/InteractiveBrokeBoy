export const example = [
    {
        id: 1,
        title: 'Example 1',
        amount: 1000,
        date: '1/1/22',
        rating: '😁'
    },
    {
        id: 2,
        title: 'Example 2',
        amount: 2000,
        date: '2/2/22',
        rating: '😊'
    },
    {
        id: 3,
        title: 'Example 3',
        amount: 3000,
        date: '3/3/22',
        rating: '😘'
    },
    {
        id: 4,
        title: 'Example 4',
        amount: 4000,
        date: '4/4/22',
        rating: '😒'
    },
    {
        id: 5,
        title: 'Example 5',
        amount: 5000,
        date: '5/5/22',
        rating: '🤣'
    },
    {
        id: 6,
        title: 'Example 6',
        amount: 6000,
        date: '6/6/22',
        rating: '❤️'
    }
]